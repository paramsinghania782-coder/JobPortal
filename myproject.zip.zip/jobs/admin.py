from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import UserProfile, Job, Application

# 1. Profile ko User ke andar hi dikhane ke liye Inline banayenge
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'User Profile'

# 2. User Admin ko customize karenge
class CustomUserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline,)  # Profile form yahan jod diya
    
    # List mein kya dikhana hai
    list_display = ('username', 'email', 'get_user_role', 'is_staff')
    
    # Search aur Filter options
    list_filter = ('is_staff', 'is_superuser')
    search_fields = ('username', 'email')

    # Ye function UserProfile se Role nikal kar layega
    def get_user_role(self, obj):
        # Check karenge ki user ke paas profile hai ya nahi
        if hasattr(obj, 'userprofile'):
            # DHYAN DEIN: Maine yahan field ka naam 'role' mana hai.
            # Agar tumhare models.py mein iska naam 'user_type' hai to use badal dena.
            return obj.userprofile.role 
        return '-'
    
    get_user_role.short_description = 'Role'  # Column ka naam

# 3. Purane User ko hata kar naya wala register karo
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass

admin.site.register(User, CustomUserAdmin)
admin.site.register(Job)
admin.site.register(Application)